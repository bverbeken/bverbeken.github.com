package models;

import play.data.validation.Phone;

public class PhoneModel {

	@Phone
	public String phone;


}
