package models;

import play.data.validation.URL;

public class URLModel {

	@URL
	public String url;
}
