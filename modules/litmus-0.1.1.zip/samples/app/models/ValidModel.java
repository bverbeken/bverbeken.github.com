package models;

import play.data.validation.Valid;

public class ValidModel {

	@Valid
	public Person validPerson;


}
